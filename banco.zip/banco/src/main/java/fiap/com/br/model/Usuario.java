package fiap.com.br.model;

public class Usuario {
    private String titular;
    private int numero;
    private String tipo;
    private boolean ativa;
    private double limite;
    private int saldo;


public Usuario( String titular, int numero, String tipo, boolean ativa, double limite, int saldo) 
{   
    this.titular = titular;
    this.numero = numero;
    this.tipo = tipo;
    this.ativa = ativa;
    this.limite = limite;
    this.saldo = saldo;
}


	public Usuario(String nome, String numero2, String conta, boolean ativa2) {
}


    public String getTitular() {
		return this.titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public int getNumero() {
		return this.numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getTipo() {
		return this.tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public boolean isAtiva() {
		return this.ativa;
	}

	public void setAtiva(boolean ativa) {
		this.ativa = ativa;
	}

	public int getLimite() {
		return (int) this.limite;
	}

	public void setLimite(double limite) {
		this.limite = limite;
	}

	public int getSaldo() {
		return this.saldo;
	}

	public void setSaldo(int saldo) {
		this.saldo = saldo;
	}


    public String getFuncionarioSolicitante() {
        return null;
    }


	public int getNumero1() {
		return 0;
	}}



