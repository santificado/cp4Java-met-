package fiap.com.br;

import javafx.fxml.Initializable;

public class SecondaryController implements Initializable{
    
}
