package fiap.com.br;


import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import fiap.com.br.model.Usuario;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

public class PrimaryController implements Initializable{

    @FXML
    TextField textFieldNome;
    
    @FXML
    TextField textFieldNumero;
    
    @FXML
    ChoiceBox<String> choiceBoxConta;
    
    @FXML
    ChoiceBox<String> choiceBoxAtiva;

    @FXML
    TextField textFieldLimite;

    @FXML
    TextField textFieldSaldo;
    
    @FXML
    Button buttonSalvar;


    String server = "sql719.main-hosting.eu";
    String database = "u553405907_fiap";
    String username = "u55345907_fiap";
    String pass = "Fiap@2022";
    String url = "jdbc:oracle://185.211.7.205:3306/u553405907_fiap";
   
    public void salvar() {
        var usuario = carregarUsuarioDoBanco();
        System.out.println(usuario);

        String sql = String.format("INSERT INTO USUARIOS (id_usuario, titular, numero, tipo, ativa, limite, saldo) " +
                "VALUES (usuario_seq.nextval, '%s', '%s', '%s', '%s')",
                usuario.getTitular(),
                usuario.getNumero(),
                usuario.isAtiva(),
                usuario.getLimite(),
                usuario.getSaldo());
        System.out.println(sql);
    }

    private Usuario carregarUsuarioDoBanco() {
        String nome = textFieldNome.getText();
        String numero = textFieldNumero.getText();
        String conta = choiceBoxConta.getValue();
        boolean ativa = choiceBoxAtiva.getValue() != null;

        return new Usuario(nome, numero, conta, ativa);

    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        choiceBoxConta.getItems().addAll(List.of("CONTA DEPÓSITO", "CONTA PAGAMENTO", "CONTA CORRENTE", "cONTA POUPANÇA", "CONTA SALÁRIO", "CONTA UNIVERSITÁRIA", "CONTA DIGITAL"));
        choiceBoxAtiva.getItems().addAll(List.of("ATIVA", "INATIVA"));    
    }


}
